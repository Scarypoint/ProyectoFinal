
INSERT INTO `clientes` (`nombre`, `apellido`, `foto`) VALUES ('NOMBRE', 'APELLIDO', 'FOTO');
UPDATE `clientes` SET `nombre`='NOMBRE1', `apellido`='APELLIDO1', `foto`='FOTO1' WHERE  `id`=1;
DELETE FROM `clientes` WHERE  `id`=1;
SELECT * FROM `clientes` LIMIT 1000;